from email import charset
from django.http import HttpResponse
from django.shortcuts import render
from loginPage import views
import pymysql as m

# Create your views here.

def index(request):
  return render(request, 'loginPage/index.html')

def insertToSQL(a,b):
  my_query=f"""insert into book values(14, '{a}', '{b}', 10000);
  """
  con = m.connect(host='localhost', user="root", passwd="1234", db="my_data_1", charset="utf8",port=3307)
  cur = con.cursor()
  cur.execute(my_query)
  con.commit()
  con.close()   

def receivePost(request):
  #login_id = login_pw = "아 몰랑"
  if request.method == 'POST':
    login_id = request.POST.get('id')
    login_pw = request.POST.get('pw')
    insertToSQL(login_id, login_pw)
  return HttpResponse(f"{login_id}와 {login_pw} 잘 받았습니다.")
  
  