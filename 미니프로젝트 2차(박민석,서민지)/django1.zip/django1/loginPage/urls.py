from django.urls import path
from loginPage import views 

app_name = 'loginPage'
urlpatterns = [
    path('', views.index, name=app_name),
    path('receivePost', views.receivePost, name='receivePost'),
]