from django.urls import path
from . import views 

urlpatterns = [
    path('aaa/',views.index2),
    path('', views.index),
    path('',views.index3)
]