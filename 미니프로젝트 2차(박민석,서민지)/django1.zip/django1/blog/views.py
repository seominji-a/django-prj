from django.shortcuts import render

# Create your views here.

mes_dict = {
  'Reg_res':23.45,
  'cl_res':['A','B','A','A']
  }
def index(request):
  return render(request, 'blog/index.html', mes_dict)

def index2(request):
  return render(request, 'blog/index2.html')

def index3(request):
  return render(request, 'blog/index3.html')
