from email import charset
from django.http import HttpResponse
from django.shortcuts import render, redirect
from prjmin import views
import pymysql as m

# Create your views here.

def index(request):
  return render(request, 'prjmin/index.html')

def index2(request):
  return render(request, 'prjmin/index2.html')
  # return render(request, 'prjmin/index2.html' , {'member_reg': "ok"} )

def index3(request):
  return render(request, 'prjmin/index3.html')

def insertToSQL(a,b,c,d):
  my_query=f"""insert into user values({a}, '{b}', '{c}', '{d}');
  """
  con = m.connect(host='localhost', user="root", passwd="1234", db="my_data_1", charset="utf8",port=3307)
  cur = con.cursor()
  cur.execute(my_query)
  con.commit()
  con.close()   

def insertTologinSQL(a):
  my_query4=f"""insert into login values(1,{a});
  """
  con = m.connect(host='localhost', user="root", passwd="1234", db="my_data_1", charset="utf8",port=3307)
  cur = con.cursor()
  cur.execute(my_query4)
  con.commit()
  con.close()   
  
def selectToSQL(a,b):
    my_query2=f"""select * from user where loginid = {a} and loginpw = '{b}';
    """
    con=m.connect(host='localhost', user="root", passwd="1234", db="my_data_1", charset="utf8"
    ,port=3307)
    cur = con.cursor() 
    cur.execute(my_query2)
    # con.commit()
    res=cur.fetchall()
    con.close()
    return res

def doublecheckToSQL(a):
    my_query3=f"""select * from user where loginid = {a};
    """
    con=m.connect(host='localhost', user="root", passwd="1234", db="my_data_1", charset="utf8"
    ,port=3307)
    cur = con.cursor() 
    cur.execute(my_query3)
    # con.commit()
    res=cur.fetchall()
    con.close()
    return res

def deleteTologinSQL():
    my_query5=f"""delete from login where numid = 1;
    """
    con=m.connect(host='localhost', user="root", passwd="1234", db="my_data_1", charset="utf8"
    ,port=3307)
    cur = con.cursor() 
    cur.execute(my_query5)
    con.commit()
    res=cur.fetchall()
    con.close()
    return res



def receivePost(request):
  #login_id = login_pw = "아 몰랑"
  if request.method == 'POST':
    login_id = request.POST.get('ID')
    login_pw = request.POST.get('Password')
    login_email = request.POST.get('email')
    login_number=  request.POST.get('Number')
    moscheck=doublecheckToSQL(login_id)
    if len(moscheck)==1:
      return HttpResponse("<script>alert('중복된 아이디입니다 다른 아이디를 선택해주세요'); location.href='/prjmin';</script>")
    insertToSQL(login_id, login_pw, login_email, login_number)
  # return HttpResponse(f"{login_id}와 {login_pw}와 {login_email}와 {login_number} 잘 받았습니다.")    
    return HttpResponse(f"<script>alert('회원{login_id}이 회원가입되었습니다.\\n\\n 가입한 정보로 로그인 해 주십시오.'); location.href='/prjmin';</script>")
    # return redirect('/prjmin') 

def receivedoPost(request):
  if request.method == 'POST':
    login_id = request.POST.get('in_ID')
    login_pw = request.POST.get('in_password')
    mos=selectToSQL(login_id, login_pw)
    # mos는 튜플
    if len(mos)==1: 
      # 튜플의 수를 셈
      # 만약 튜플의 수가 1일 경우, 회원 정보가 존재한다고 가정하고 로그인됨
       insertTologinSQL(login_id)
       return HttpResponse(f"<script>alert('회원{login_id}이 로그인되었습니다.'); location.href='/prjmin/login';</script>")
    if len(mos)==0:
      # 만약 튜플의 수가 0일 경우, 회원 정보가 존재하지 않는다고 가정하고 로그인되지 않음
      return HttpResponse("<script>alert('존재하는 회원정보가 없습니다.\\n\\n다시 로그인 해 주십시오.');location.href='/prjmin';</script>")

def receivelogoutPost(request):
  if request.method == 'POST':
    deleteTologinSQL()
    return HttpResponse(f"<script>alert('회원이 로그아웃되었습니다.'); location.href='/prjmin';</script>")
