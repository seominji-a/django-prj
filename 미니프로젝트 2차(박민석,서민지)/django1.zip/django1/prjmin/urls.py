from django.urls import path
from . import views 

app_name = 'prjmin'
urlpatterns = [
    path('', views.index , name=app_name),
    path('login/',views.index2),
    path('loginfo/',views.index3),
    path('receivePost', views.receivePost, name='receivePost'),
    path('receivedoPost', views.receivedoPost, name='receivedoPost'),
    path('receivelogoutPost', views.receivelogoutPost, name='receivelogoutPost'),
]