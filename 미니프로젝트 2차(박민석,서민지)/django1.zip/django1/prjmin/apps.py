from django.apps import AppConfig


class PrjminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prjmin'
